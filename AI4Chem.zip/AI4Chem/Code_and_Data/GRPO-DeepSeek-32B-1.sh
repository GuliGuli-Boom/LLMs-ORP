# External vLLM

# Assume we have two nodes, one with 8 GPUs of 80GB each (880G) and another with 2 GPUs of 80GB each (2 80G).
#   NODE1. The node with 2*80G will be used to deploy the vLLM server.
#   NODE2. The node with 8*80G will be used for full-parameter fine-tuning of the 32B model.

# Note : Use beta=0 to disable the reference model; otherwise, it may lead to Out-of-Memory (OOM) errors.

# NODE2 for Training
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
NPROC_PER_NODE=8 \
swift rlhf \
    --rlhf_type grpo \
    --model /DeepSeek-R1-32B-CoT-SFT \
    --external_plugins /plugin.py \
    --reward_funcs chem_reward \
    --system '/prompt.txt' \
    --use_vllm true \
    --vllm_device auto \
    --vllm_mode colocate \
    --vllm_server_host XXX \
    --vllm_server_port 8000 \
    --train_type lora \
    --torch_dtype bfloat16 \
    --dataset /Data/GRPO-Data \
    --output_dir /GRPO/Save \
    --max_completion_length 2500 \
    --num_train_epochs 3 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 8 \
    --learning_rate 1e-5 \
    --gradient_accumulation_steps 8 \
    --save_strategy 'steps' \
    --eval_strategy 'steps' \
    --eval_steps 10000 \
    --save_steps 100 \
    --save_total_limit 1 \
    --logging_steps 1 \
    --warmup_ratio 0.05 \
    --dataloader_num_workers 4 \
    --dataset_num_proc 4 \
    --num_generations 8 \
    --temperature 0.6 \
    --top_p 0.9 \
    --top_k 50 \
    --deepspeed zero3 \
    --log_completions true \
    --num_iterations 1 \
    --async_generate false \
    --report_to wandb \
    --beta 0.01
